import { HttpClient } from '@angular/common/http';
import { Directive } from '@angular/core';
import { AsyncValidator, FormControl, FormGroup, NG_ASYNC_VALIDATORS, ValidationErrors } from '@angular/forms';
import { map, Observable, of } from 'rxjs';
import { IBook } from './model';

@Directive({
  selector: '[FormValidation]',
  providers: [{provide: NG_ASYNC_VALIDATORS, useExisting: FormValidationDirective, multi: true}]
})
export class FormValidationDirective implements  AsyncValidator {

  private readonly url: string =  'http://localhost:3000/books';

  constructor(private httpClient: HttpClient) { }

  validate(control: FormControl): Observable<ValidationErrors  |  null>{
    let id = 0;
    //if(control.touched == false) return of(null);
    let parent = control.parent;
    if(typeof(parent) == typeof(new FormGroup({}))){
      let group = parent as FormGroup;
      id = group.controls['id'].value ?? 0; 
    }
    return this.httpClient.get<IBook[]>(this.url).pipe(
      map((data)=> data.filter(x => x.title ==  control.value && x.id != id.toString()).length == 0 ? null : {error: 'title must be unique'})
    )
  }
}
