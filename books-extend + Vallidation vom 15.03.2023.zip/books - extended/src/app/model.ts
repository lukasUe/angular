export interface IBook{
    id: string
    title: string
    isbn: string
    author: string
    preview: string
    genre: string
    borrowed: Date,
    returned: Date,
    fee: number
}

export interface IBookGenre{
    title: string
}