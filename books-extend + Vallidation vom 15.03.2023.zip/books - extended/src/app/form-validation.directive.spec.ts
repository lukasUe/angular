import { FormValidationDirective } from './form-validation.directive';

describe('FormValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new FormValidationDirective();
    expect(directive).toBeTruthy();
  });
});
