import { FormControl, FormGroup, ValidationErrors } from "@angular/forms";

export class PreviewValidator {
    static checkPreview(control: FormControl) {
        const checkValue = control.value;

        if(checkValue.length <= 0) 
            return { checkPreview: {valid:false}}

        if(checkValue.length > 1000) 
            return { checkPreview: {valid:false}}

        return null
    }

    static checkReturn(control: FormControl): ValidationErrors |  null{
        if(control.value == '') return null;
        let parent = control.parent;
        let group: FormGroup = new FormGroup({});
        if(typeof(parent) == typeof(new FormGroup({}))){
            group = parent as FormGroup;
        }
        if(group.controls['borrowed']?.value == '') return {error: 'You cannot bring back what you didnot borrowed'};
        let borrowDate = new Date(group.controls['borrowed']?.value);
        let checkDate = new Date(control.value);
        if(borrowDate.valueOf() > checkDate.valueOf()) return {error: 'wrong Date: borrowed' +borrowDate.toDateString() + ' return date:'+checkDate.toDateString()};
        return null;
    }
}