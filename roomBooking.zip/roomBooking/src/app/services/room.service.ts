import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IRoom } from '../models/booking';

@Injectable({
  providedIn: 'root',
})
export class RoomService {
  private urlRoot = 'http://localhost:3000/room';

  constructor(private httpClient: HttpClient) {}

  getAllBookings(): Observable<IRoom[]> {
    return this.httpClient.get<IRoom[]>(this.urlRoot);
  }
}
