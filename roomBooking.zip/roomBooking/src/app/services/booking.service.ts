import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IBooking } from '../models/booking';

@Injectable({
  providedIn: 'root',
})
export class BookingService {
  private urlRoot = 'http://localhost:3000/booking';
  constructor(private httpClient: HttpClient) {}

  getAllBookings(): Observable<IBooking[]> {
    return this.httpClient.get<IBooking[]>(this.urlRoot);
  }

  getBookingById(id: number): Observable<IBooking> {
    return this.httpClient.get<IBooking>(this.urlRoot + '/' + id);
  }

  addBooking(booking: IBooking): Observable<IBooking> {
    return this.httpClient.post<IBooking>(this.urlRoot, booking);
  }

  updateBooking(booking: IBooking): Observable<IBooking> {
    return this.httpClient.put<IBooking>(
      this.urlRoot + '/' + booking.id,
      booking
    );
  }

  deleteBooking(id: number): Observable<any> {
    return this.httpClient.delete(this.urlRoot + '/' + id);
  }
}
