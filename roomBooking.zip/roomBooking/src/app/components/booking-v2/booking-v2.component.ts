import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { IBooking } from 'src/app/models/booking';
import { BookingService } from 'src/app/services/booking.service';

@Component({
  selector: 'app-booking-v2',
  templateUrl: './booking-v2.component.html',
  styleUrls: ['./booking-v2.component.scss'],
})
export class BookingV2Component implements OnInit {
  searchText = '';

  bookingList: IBooking[] = [];
  bookings: MatTableDataSource<IBooking> = new MatTableDataSource();

  displayedColumns: string[] = [
    'id',
    'name',
    'room',
    'date',
    'from',
    'to',
    'price',
    'options',
  ];

  constructor(private bookingService: BookingService) {}

  ngOnInit(): void {
    this.loadBooking();
  }

  loadBooking() {
    this.bookingService.getAllBookings().subscribe((data) => {
      this.bookingList = data;
      this.bookings.data = data;
      console.log(this.bookings);
    });
  }

  deleteBooking(id: number) {
    this.bookingService.deleteBooking(id).subscribe((_) => this.loadBooking());
  }

  onSearchTextChange() {
    let result = this.bookingList.filter((x) =>
      x.name.toUpperCase().includes(this.searchText.toUpperCase())
    );
    this.bookings.data = result;
  }
}
