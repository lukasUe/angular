import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IRoom } from 'src/app/models/booking';
import { BookingService } from 'src/app/services/booking.service';
import { RoomService } from 'src/app/services/room.service';
import { PriceValidators } from 'src/app/validators/price-validators';
import { TimeValidator } from 'src/app/validators/time-validators';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.scss'],
})
export class BookingDetailsComponent implements OnInit {
  rooms: IRoom[] = [];

  id: number = 0;
  detailsForm: FormGroup = new FormGroup({});

  inputName = new FormControl('', [
    Validators.required,
    Validators.minLength(2),
  ]);
  inputRoom = new FormControl('', [Validators.required]);
  inputDate = new FormControl('', [Validators.required]);
  inputFrom = new FormControl('', [Validators.required]);
  inputTo = new FormControl('', [Validators.required]);
  inputPrice = new FormControl('', [
    Validators.required,
    PriceValidators.checkPrice,
  ]);

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private bookingService: BookingService,
    private roomService: RoomService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadRooms();
    this.initForm();

    if (this.router.url.indexOf('booking/') > 0) {
      this.id = this.route.snapshot.params['id'];
      this.bookingService.getBookingById(this.id).subscribe((data) => {
        this.detailsForm.patchValue(data);
      });
    }
  }

  initForm() {
    this.detailsForm = this.formBuilder.group(
      {
        id: '',
        name: this.inputName,
        room: this.inputRoom,
        date: this.inputDate,
        from: this.inputFrom,
        to: this.inputTo,
        price: this.inputPrice,
      },
      { validator: TimeValidator.checkTime }
    );
  }

  loadRooms() {
    this.roomService.getAllBookings().subscribe((data) => {
      this.rooms = data;
    });
  }

  submit() {
    if (this.id != 0) {
      this.bookingService
        .updateBooking(this.detailsForm.value)
        .subscribe((data) => {
          this.detailsForm.patchValue(data);
        });
    } else {
      this.bookingService
        .addBooking(this.detailsForm.value)
        .subscribe((data) => {
          this.detailsForm.patchValue(data);
        });
    }
    this.cancel();
  }

  cancel() {
    this.router.navigate(['/booking']);
  }

  getErrorForName(): string {
    let result = '';
    if (this.inputName.hasError('minlength')) {
      result += 'Name muss mind. 2 Zeichen lang sein!';
    }
    if (this.inputName.hasError('required')) {
      result += 'Name muss befüllt werden.';
    }
    return result;
  }

  getErrorForRoom(): string {
    let result = '';
    if (this.inputRoom.hasError('required')) {
      result += 'Raum muss ausgewählt werden.';
    }
    return result;
  }

  getErrorForDate(): string {
    let result = '';
    if (this.inputDate.hasError('required')) {
      result += 'Datum muss befüllt werden.';
    }
    return result;
  }

  getErrorForFrom(): string {
    let result = '';
    if (this.inputFrom.hasError('required')) {
      result += 'Von Uhrzeit muss befüllt werden.';
    }
    return result;
  }

  getErrorForTo(): string {
    let result = '';
    if (this.inputTo.hasError('required')) {
      result += 'Bis Uhrzeit muss befüllt werden.';
    }
    return result;
  }

  getErrorForPrice(): string {
    let result = '';
    if (this.inputPrice.hasError('required')) {
      result += 'Preis muss befüllt werden.';
    }
    if (this.inputPrice.hasError('priceNotNan')) {
      result += 'Preis muss Zahl sein.';
    }
    if (this.inputPrice.hasError('priceZero')) {
      result += 'Preis muss größer 0 sein.';
    }
    return result;
  }
}
