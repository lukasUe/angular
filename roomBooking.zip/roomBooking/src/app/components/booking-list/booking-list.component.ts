import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatTable } from '@angular/material/table';
import {
  Subscription,
  debounceTime,
  distinctUntilChanged,
  fromEvent,
  map,
  startWith,
} from 'rxjs';
import { IBooking } from 'src/app/models/booking';
import { BookingService } from 'src/app/services/booking.service';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrls: ['./booking-list.component.scss'],
})
export class BookingListComponent implements OnInit {
  searchText = '';
  searchSubscription: Subscription | undefined;
  @ViewChild('searchInput', { static: true }) searchInput:
    | ElementRef
    | undefined;

  bookings: IBooking[] = [];

  displayedColumns: string[] = [
    'id',
    'name',
    'room',
    'date',
    'from',
    'to',
    'price',
    'options',
  ];
  @ViewChild(MatTable) table: MatTable<IBooking> | undefined;

  constructor(private bookingService: BookingService) {}

  ngOnInit(): void {
    this.searchSubscription = fromEvent<any>(
      this.searchInput?.nativeElement,
      'keyup'
    )
      .pipe(
        map((event) => event.target.value),
        startWith(''),
        debounceTime(500),
        distinctUntilChanged()
      )
      .subscribe((data) => {
        this.loadBooking();
      });
    this.loadBooking();
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  loadBooking() {
    this.bookingService.getAllBookings().subscribe((data) => {
      this.bookings = data.filter((p) => p.name.indexOf(this.searchText) >= 0);
      this.table?.renderRows();
    });
  }

  deleteBooking(id: number) {
    this.bookingService.deleteBooking(id).subscribe((_) => this.loadBooking());
  }
}
