import { FormControl, ValidationErrors } from '@angular/forms';

export class PriceValidators {
  static checkPrice(control: FormControl): ValidationErrors | null {
    const checkNumber: number = Number.parseFloat(control.value);
    if (Number.isNaN(checkNumber)) return { priceNotNan: { valid: false } };
    if (checkNumber <= 0) return { priceZero: { valid: false } };
    return null;
  }
}
