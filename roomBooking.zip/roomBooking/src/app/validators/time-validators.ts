import { group } from '@angular/animations';
import { FormControl, FormGroup, ValidationErrors } from '@angular/forms';

export class TimeValidator {
  static checkTime(control: FormControl): ValidationErrors | null {
    const fromTime = control.get('from')?.value;
    const toTime = control.get('to')?.value;
    if (toTime && fromTime && fromTime >= toTime) {
      control.get('to')?.setErrors({ checkTime: false });
      return { checkTime: false };
    }
    return null;
  }
}
