import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookingListComponent } from './components/booking-list/booking-list.component';
import { BookingDetailsComponent } from './components/booking-details/booking-details.component';

const routes: Routes = [
  { path: '', component: BookingListComponent },
  { path: 'booking', component: BookingListComponent },
  { path: 'booking-add', component: BookingDetailsComponent },
  { path: 'booking/:id', component: BookingDetailsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
