import { Time } from '@angular/common';

export interface IBooking {
  id: number | undefined;
  name: string;
  room: string;
  date: Date;
  from: Time;
  to: Time;
  price: number;
}

export interface IRoom {
  room: string;
}
