import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BooksApiService {
  private urlRoot = 'https://api.airtable.com/v0/appuF6og13AGBF0EF/books';
  private headers =  {
    headers: new HttpHeaders(
      { Authorization: 'Bearer pate3stIxnUKmQIY8.f01db223241727662b525115462b85c274832947379e1c09db54a5e682d6453d' }
    )
  }

  constructor(private httpClient: HttpClient) {
  }

}
