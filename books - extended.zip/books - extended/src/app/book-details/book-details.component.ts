import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BooksApiService } from '../books-api.service';
import { IsbnValidator } from '../isbn-validator.directive';
import { IBook, IBookGenre } from '../model';
import { PreviewValidator } from '../preview-validator';
import { BookGenreService } from '../Services/book-genre.service';
import { BooksService } from '../Services/book.service';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {

  id: number = 0
  detailmodel?: IBook
  genreList: IBookGenre[] = []
  detailsForm: FormGroup = new FormGroup({default: new FormControl()})
  
  constructor( 
    private router: Router, 
    private activatedRoute: ActivatedRoute, 
    private bookService: BooksService, 
    private genreService: BookGenreService, 
    private formBuilder: FormBuilder) {

  }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.params['id']
    this.initForm() 
    this.getGenres() 
    this.getBookById() 
  }


  submit() {
    this.bookService.updateBook(this.detailsForm.value).subscribe(() => this.router.navigate(["books"]))
  }

  onBack() {
    this.router.navigate(["books"])
  }

  initForm() { //Form initialisieren
    this.detailsForm = this.formBuilder.group({ //alle Daten, auch die die nicht angezeigt werden
        id: [0],
        title: ['',[Validators.required]],
        isbn: ['',[Validators.required, new IsbnValidator()]],
        author: ['',[Validators.maxLength(256)]],
        preview: ['',[PreviewValidator.checkPreview]],
        genre: [''],
        borrowed:[''],
        returned:[''],
        fee:[]
    })
  }
  
  getGenres() {
    this.genreService.getAllBookGenres().subscribe(data => this.genreList = data)
  }
  
  getBookById() {
    this.bookService.getBookById(this.id).subscribe({
      next: data => {	this.detailmodel = data
        this.detailsForm.patchValue(data)	},
      error: err => console.error(err),
      complete: () => console.log(`finished getbyid ${this.detailmodel}`)
  })}



}


