import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { IBook } from '../model';
import { BooksService } from '../Services/book.service';


@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  constructor(private booksService: BooksService, private router: Router) {
  }
  displayedColumns: string[] = ['id', 'title', 'isbn', 'author', 'preview', 'genre', 'borrowed', 'returned', 'fee', 'delete']

  books: IBook[] = []; //für den Filter
  booksTableSource: MatTableDataSource<IBook> = new MatTableDataSource();
  @ViewChild(MatTable) table: MatTable<IBook> | undefined

  ngOnInit(): void {
    this.getAllBooks()
  }

  getAllBooks() {
    this.booksService.getAllBooks().subscribe(data => { console.log(data)
      this.books = data                             
      this.booksTableSource.data = data; })

  }

  delete(item: IBook) {
    this.booksService.deleteBook(item.id).subscribe(() => { this.getAllBooks(); })
  }

  add() {
    this.router.navigate(['/books/0']);
  }

  //filter
  inputText: string = ""
  onInputChange() {
    let result = this.books.filter(x => x.title.includes(this.inputText))
   			this.booksTableSource.data = result;
  }

}
